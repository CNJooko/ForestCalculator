'use strict';

// ========== UI 渲染与交互 ==========
ForestCalc.escapeHTML = function(str) {
    var div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
};

// 依赖 species-db.js, calculator.js, storage.js

var ForestCalc = window.ForestCalc || {};

// 批量计算数据（全局状态）
ForestCalc.batchRows = [];

// ========== 撤销栈 ==========
ForestCalc._undoStack = [];
ForestCalc._pushUndo = function() {
  if (ForestCalc._undoStack.length >= 10) ForestCalc._undoStack.shift();
  ForestCalc._undoStack.push(ForestCalc.batchRows.map(function(r) {
    return { speciesIdx: r.speciesIdx, dbh: r.dbh, height: r.height, count: r.count || 1, _vol: r._vol, _spec: r._spec, _nonSpec: r._nonSpec, _fuel: r._fuel, _waste: r._waste };
  }));
  document.getElementById('btnUndo').disabled = false;
};

ForestCalc.undoBatch = function() {
  if (ForestCalc._undoStack.length === 0) return;
  ForestCalc.batchRows = ForestCalc._undoStack.pop();
  if (ForestCalc._undoStack.length === 0) document.getElementById('btnUndo').disabled = true;
  ForestCalc.renderBatch();
};

// ========== Toast 通知系统 ==========
ForestCalc.showToast = function(message, type) {
  type = type || 'info';
  var container = document.getElementById('toastContainer');
  var toast = document.createElement('div');
  toast.className = 'toast toast-' + type;
  var msgSpan = document.createElement('span');
  msgSpan.textContent = message;
  toast.appendChild(msgSpan);
  var closeBtn = document.createElement('button');
  closeBtn.className = 'toast-close';
  closeBtn.textContent = '\u00D7';
  closeBtn.onclick = function() {
    toast.classList.remove('show');
    setTimeout(function() { toast.remove(); }, 350);
  };
  toast.appendChild(closeBtn);
  container.appendChild(toast);
  requestAnimationFrame(function() { toast.classList.add('show'); });
  setTimeout(function() {
    toast.classList.remove('show');
    setTimeout(function() { toast.remove(); }, 350);
  }, 3000);
};

// ========== Confirm 模态框 ==========
ForestCalc.showConfirm = function(message, onConfirm) {
  var overlay = document.getElementById('confirmOverlay');
  overlay.setAttribute('role', 'dialog');
  overlay.setAttribute('aria-modal', 'true');
  document.getElementById('confirmMessage').textContent = message;
  overlay.style.display = 'flex';
  var yesBtn = document.getElementById('confirmYes');
  var noBtn = document.getElementById('confirmNo');
  var keyHandler = function(e) {
    if (e.key === 'Enter') { e.preventDefault(); cleanup(); if (typeof onConfirm === 'function') onConfirm(); }
    else if (e.key === 'Escape') { e.preventDefault(); cleanup(); }
  };
  var cleanup = function() {
    overlay.style.display = 'none';
    yesBtn.onclick = null;
    noBtn.onclick = null;
    document.removeEventListener('keydown', keyHandler);
  };
  yesBtn.onclick = function() { cleanup(); if (typeof onConfirm === 'function') onConfirm(); };
  noBtn.onclick = cleanup;
  yesBtn.focus();
  document.addEventListener('keydown', keyHandler);
};

// ========== 初始化 ==========
ForestCalc.initApp = function() {
  var sel = document.getElementById('speciesSelect');
  ForestCalc.SPECIES.forEach(function(s, i) {
    var o = document.createElement('option');
    o.value = i; o.textContent = s.name + '（' + s.latin + '）';
    sel.appendChild(o);
  });
  ForestCalc.onSpeciesChange();
  ForestCalc.renderDataPanel();
  ForestCalc.renderSavedList();
  ForestCalc.renderHistory();
  // 恢复暗色主题
  if (localStorage.getItem('fc_theme') === 'dark') {
    document.body.classList.add('dark');
    document.getElementById('themeToggle').textContent = '☀️';
  }
  // 树种搜索过滤
  var speciesSearch = document.getElementById('speciesSearch');
  if (speciesSearch) {
    speciesSearch.addEventListener('input', function() {
      var filter = this.value.toLowerCase();
      for (var i = 0; i < sel.options.length; i++) {
        sel.options[i].style.display = sel.options[i].textContent.toLowerCase().indexOf(filter) !== -1 ? '' : 'none';
      }
    });
  }
  // Enter 快捷键：D/H 输入框按 Enter 触发计算
  var dbhInput = document.getElementById('dbhInput');
  var heightInput = document.getElementById('heightInput');
  if (dbhInput && heightInput) {
    dbhInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (e.ctrlKey) { ForestCalc.addToBatch(); return; }
        if (!heightInput.value.trim()) { heightInput.focus(); }
        else { ForestCalc.calcSingle(); }
      }
    });
    heightInput.addEventListener('keydown', function(e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (e.ctrlKey) { ForestCalc.addToBatch(); return; }
        ForestCalc.calcSingle();
      }
    });
    var countInput = document.getElementById('countInput');
    if (countInput) {
      countInput.addEventListener('keydown', function(e) {
        if (e.ctrlKey && e.key === 'Enter') {
          e.preventDefault();
          ForestCalc.addToBatch();
        }
      });
    }
    dbhInput.addEventListener('blur', function() {
      var dbh = parseFloat(this.value);
      if (!dbh || dbh <= 0) return;
      var hInput = document.getElementById('heightInput');
      var hVal = parseFloat(hInput.value);
      if (!isNaN(hVal) && hVal > 0) return;
      var selSpecies = ForestCalc.SPECIES[document.getElementById('speciesSelect').value];
      var hRatio = (selSpecies && selSpecies.defaultHRatio) ? selSpecies.defaultHRatio : 0.75;
      var height = Math.round(dbh * hRatio * 10) / 10;
      hInput.value = height;
      ForestCalc.showToast('已自动填入树高 H=' + height + 'm（H/D=' + hRatio.toFixed(2) + '）', 'info');
    });
  }
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !e.target.closest('input,textarea,select')) {
      var csvPanel = document.getElementById('csvImportPanel');
      var ytPanel = document.getElementById('yieldTableOptions');
      if (csvPanel && csvPanel.style.display !== 'none') { csvPanel.style.display = 'none'; return; }
      if (ytPanel && ytPanel.style.display === 'block') { ytPanel.style.display = 'none'; return; }
    }
  });

  // v1.7.6: 绑定虚拟滚动事件
  ForestCalc._bindVirtualScroll();
};

// ========== 树种切换 ==========
ForestCalc.onSpeciesChange = function() {
  var s = ForestCalc.SPECIES[document.getElementById('speciesSelect').value];
  var cls = s.reliability === 'high' ? 'badge-high' : s.reliability === 'medium' ? 'badge-medium' : 'badge-low';
  var txt = s.reliability === 'high' ? '省标验证' : s.reliability === 'medium' ? '部标/文献' : '待验证';
  var formulaStr;
  if (s.isDynamic && s.b1 !== undefined) {
    formulaStr = 'V = ' + s.a + ' × D<sup>(' + s.b1 + (s.b2>=0?'+':'') + s.b2 + '×(D+H))</sup> × H<sup>(' + s.c1 + (s.c2>=0?'+':'') + s.c2 + '×(D+H))</sup>';
  } else {
    formulaStr = 'V = ' + s.a + ' × D<sup>' + s.b + '</sup> × H<sup>' + s.c + '</sup>';
  }
  var bar = document.getElementById('speciesBar');
  bar.innerHTML =
    '<span class="badge ' + cls + '">' + txt + '</span>' +
    formulaStr +
    '&nbsp;|&nbsp; ' + s.source +
    '&nbsp;|&nbsp; 出材率: 规格' + (s.yieldRates.spec*100).toFixed(0) + '% 非规格' + (s.yieldRates.nonSpec*100).toFixed(0) + '% 薪材' + (s.yieldRates.fuel*100).toFixed(0) + '% 废材' + (s.yieldRates.waste*100).toFixed(0) + '%' +
    '<br><small>' + s.note + '</small>';
  // 树种切换时同步更新收方表面板H/D比默认值
  if (s.defaultHRatio !== undefined) {
    var ytPanel = document.getElementById('yieldTableOptions');
    var hRatioInput = document.getElementById('hRatioYield');
    if (ytPanel && ytPanel.style.display === 'block' && hRatioInput) {
      hRatioInput.value = s.defaultHRatio;
    }
  }
};

// ========== 单株计算 ==========
ForestCalc.calcSingle = function() {
  var s = ForestCalc.getActiveSpecies();
  var dbh = parseFloat(document.getElementById('dbhInput').value);
  var height = parseFloat(document.getElementById('heightInput').value);
  var count = parseInt(document.getElementById('countInput').value) || 1;
  var area = parseFloat(document.getElementById('areaInput').value) || 0;

  if (!dbh || dbh <= 0 || !height || height <= 0) {
    document.getElementById('singleResult').innerHTML = '<div class="callout callout-warn">请输入有效的胸径和树高。</div>';
    document.getElementById('singleResult').classList.add('show');
    return;
  }
  if (s.a === 0) {
    document.getElementById('singleResult').innerHTML = '<div class="callout callout-danger">该树种暂无可靠的二元材积公式系数，无法计算。</div>';
    document.getElementById('singleResult').classList.add('show');
    return;
  }
  if (dbh > 300) { ForestCalc.showToast('胸径超出合理范围（>300cm），请核实。', 'warn'); return; }
  if (height > 100) { ForestCalc.showToast('树高超出合理范围（>100m），请核实。', 'warn'); return; }
  if (count < 1) { ForestCalc.showToast('棵数至少为1。', 'warn'); return; }

  var vol1 = ForestCalc.calcVolume(s, dbh, height);
  var vol = vol1 * count;
  // 与 calcBatch 保持一致：直接传参调用 calcYieldRates，解耦 DOM
  var yTotalVal = parseFloat(document.getElementById('yTotal').value) || 0;
  var customTotal = (yTotalVal > 0 && yTotalVal <= 1) ? yTotalVal : null;
  var yr = ForestCalc.calcYieldRates(s, customTotal);
  var y1 = { spec: vol1*yr.spec, nonSpec: vol1*yr.nonSpec, fuel: vol1*yr.fuel, waste: vol1*yr.waste };
  var y = {
    spec: y1.spec * count,
    nonSpec: y1.nonSpec * count,
    fuel: y1.fuel * count,
    waste: y1.waste * count
  };
  var totalEcon = y.spec + y.nonSpec;
  var rate = (totalEcon / vol * 100);

  // Record history
  var spName = s.name || '自定义';
  ForestCalc.addHistory(spName, dbh, height, count, vol, totalEcon);

  var areaHtml = '';
  if (area > 0) {
    areaHtml =
    '<div class="area-hero">' +
      '<div class="area-title">亩均统计（' + area.toFixed(1) + ' 亩）</div>' +
      '<div class="area-grid">' +
        '<div class="area-stat"><span class="big">' + (vol/area).toFixed(4) + '</span> m³/亩 蓄积</div>' +
        '<div class="area-stat"><span class="big">' + (totalEcon/area).toFixed(4) + '</span> m³/亩 经济材</div>' +
        '<div class="area-stat"><span class="big">' + (y.spec/area).toFixed(4) + '</span> m³/亩 规格材</div>' +
      '</div>' +
    '</div>';
  }

  // 公顷蓄积量计算
  var densityVal = parseInt(document.getElementById('density').value) || 0;
  var hectareHtml = '';
  if (densityVal > 0) {
    var haInput = { spec: y1.spec, nonSpec: y1.nonSpec, fuel: y1.fuel, waste: y1.waste };
    var ha = ForestCalc.calcPerHectare(vol1, haInput, densityVal);
    hectareHtml =
    '<div style="margin-top:12px;padding:10px;background:rgba(196,165,110,0.06);border-radius:8px;border:1px solid rgba(196,165,110,0.15);">' +
      '<h4 style="margin:0 0 6px 0;">📐 公顷蓄积量 (' + densityVal + ' 株/公顷)</h4>' +
      '<table style="width:100%;font-size:13px;">' +
      '<tr><td>总蓄积</td><td style="text-align:right;font-weight:bold;">' + ha.totalVolume.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>规格材</td><td style="text-align:right;">' + ha.totalSpec.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>非规格材</td><td style="text-align:right;">' + ha.totalNonSpec.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>薪材</td><td style="text-align:right;">' + ha.totalFuel.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>废材</td><td style="text-align:right;">' + ha.totalWaste.toFixed(3) + ' m³</td></tr>' +
      '</table></div>';
  }

  // 亩蓄积量计算
  var densityMuVal = parseInt(document.getElementById('densityMu').value) || 0;
  var muHtml = '';
  if (densityMuVal > 0) {
    var muInput = { spec: y1.spec, nonSpec: y1.nonSpec, fuel: y1.fuel, waste: y1.waste };
    var mu = ForestCalc.calcPerMu(vol1, muInput, densityMuVal);
    muHtml =
    '<div style="margin-top:8px;padding:10px;background:rgba(196,165,110,0.06);border-radius:8px;border:1px solid rgba(196,165,110,0.15);">' +
      '<h4 style="margin:0 0 6px 0;">📐 亩蓄积量 (' + densityMuVal + ' 株/亩)</h4>' +
      '<table style="width:100%;font-size:13px;">' +
      '<tr><td>总蓄积</td><td style="text-align:right;font-weight:bold;">' + mu.totalVolume.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>规格材</td><td style="text-align:right;">' + mu.totalSpec.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>非规格材</td><td style="text-align:right;">' + mu.totalNonSpec.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>薪材</td><td style="text-align:right;">' + mu.totalFuel.toFixed(3) + ' m³</td></tr>' +
      '<tr><td>废材</td><td style="text-align:right;">' + mu.totalWaste.toFixed(3) + ' m³</td></tr>' +
      '</table></div>';
  }

  var div = document.getElementById('singleResult');
  div.classList.add('show');
  div.innerHTML =
    '<div class="volume-hero">' +
      '<div class="volume-number">' + vol.toFixed(4) + '</div>' +
      '<div class="volume-unit">立方米 (m³) — ' + count + ' 株 × 单株 ' + vol1.toFixed(4) + ' m³ = 总蓄积量</div>' +
    '</div>' +
    areaHtml +
    hectareHtml +
    muHtml +
    '<div class="yield-grid">' +
      '<div class="yield-item economic">' +
        '<div class="yield-val">' + totalEcon.toFixed(4) + ' m³</div>' +
        '<div class="yield-label">经济材合计（规格+非规格）</div>' +
        '<div style="font-size:12px;color:var(--pine);margin-top:2px;">出材率 ' + rate.toFixed(1) + '%</div>' +
      (s.econBasePct !== undefined ? '<small style="color:var(--wood);font-size:10px;">📌 经济材率基准: ' + s.econBasePct + '% @D20H15 · 斜率: DB51/T 1466 (R²=0.977)</small>' : '') +
      '</div>' +
      '<div class="yield-item">' +
        '<div class="yield-val">' + y.spec.toFixed(4) + ' m³</div>' +
        '<div class="yield-label">规格材（小头直径≥6cm）</div>' +
      '</div>' +
      '<div class="yield-item">' +
        '<div class="yield-val">' + y.nonSpec.toFixed(4) + ' m³</div>' +
        '<div class="yield-label">非规格材</div>' +
      '</div>' +
      '<div class="yield-item">' +
        '<div class="yield-val">' + y.fuel.toFixed(4) + ' m³</div>' +
        '<div class="yield-label">薪材</div>' +
      '</div>' +
      '<div class="yield-item">' +
        '<div class="yield-val">' + y.waste.toFixed(4) + ' m³</div>' +
        '<div class="yield-label">废材（不可利用）</div>' +
      '</div>' +
    '</div>' +
    '<div class="callout callout-info" style="margin-top:14px;">' + ForestCalc.YIELD_DISCLAIMER + '</div>';
  document.getElementById('btnClearSingle').style.display = 'inline-block';
};

ForestCalc.clearSingle = function() {
  var div = document.getElementById('singleResult');
  div.classList.remove('show');
  div.innerHTML = '';
  document.getElementById('btnClearSingle').style.display = 'none';
};

// ========== 批量计算 ==========
ForestCalc.addToBatch = function() {
  var idx = parseInt(document.getElementById('speciesSelect').value);
  var dbh = parseFloat(document.getElementById('dbhInput').value);
  var height = parseFloat(document.getElementById('heightInput').value);
  var count = parseInt(document.getElementById('countInput').value) || 1;
  if (!dbh || dbh <= 0 || !height || height <= 0) {
    ForestCalc.showToast('请先输入有效的胸径和树高。', 'warn');
    return;
  }
  ForestCalc._pushUndo();
  ForestCalc.batchRows.push({ speciesIdx: idx, dbh: dbh, height: height, count: count });
  ForestCalc.renderBatch();
  document.getElementById('batchCard').scrollIntoView({ behavior: 'smooth' });
};

ForestCalc.addRow = function() {
  ForestCalc._pushUndo();
  var idx = parseInt(document.getElementById('speciesSelect').value) || 0;
  ForestCalc.batchRows.push({ speciesIdx: idx, dbh: '', height: '', count: 1 });
  ForestCalc.renderBatch();
};

ForestCalc.clearBatch = function() {
  ForestCalc.showConfirm('确定清空全部批量数据？', function() {
    ForestCalc._pushUndo();
    ForestCalc.batchRows = [];
    ForestCalc.renderBatch();
  });
};

ForestCalc.copyBatchRow = function(idx) {
  ForestCalc._pushUndo();
  var row = ForestCalc.batchRows[idx];
  var copy = { speciesIdx: row.speciesIdx, dbh: row.dbh, height: row.height, count: row.count || 1 };
  ForestCalc.batchRows.splice(idx + 1, 0, copy);
  ForestCalc.renderBatch();
};

ForestCalc.moveBatchRow = function(idx, direction) {
  ForestCalc._pushUndo();
  var row = ForestCalc.batchRows[idx];
  ForestCalc.batchRows.splice(idx, 1);
  ForestCalc.batchRows.splice(idx + direction, 0, row);
  ForestCalc.renderBatch();
};

// 批量行胸径失焦自动推算树高（与主输入框行为保持一致）
ForestCalc.autoFillBatchHeight = function(idx) {
  var r = ForestCalc.batchRows[idx];
  if (!r) return;
  var dbh = parseFloat(r.dbh);
  if (!dbh || dbh <= 0) return;
  var h = parseFloat(r.height);
  if (!isNaN(h) && h > 0) return; // 已有树高则不覆盖
  var s = ForestCalc.SPECIES[r.speciesIdx];
  var hRatio = (s && s.defaultHRatio) ? s.defaultHRatio : 0.75;
  r.height = Math.round(dbh * hRatio * 10) / 10;
  r._vol = null;
  ForestCalc.renderBatch();
};

// ========== CSV 粘贴导入 ==========
ForestCalc.toggleCSVImport = function() {
  var panel = document.getElementById('csvImportPanel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
};

ForestCalc.importCSV = function() {
  var text = document.getElementById('csvTextarea').value.trim();
  if (!text) { ForestCalc.showToast('请先粘贴CSV数据', 'warn'); return; }
  var lines = text.split('\n');
  var imported = 0;
  var maxRows = 500;
  var truncated = false;
  var speciesIdx = parseInt(document.getElementById('speciesSelect').value) || 0;
  ForestCalc._pushUndo();
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (!line || line.charAt(0) === '#') continue;
    var parts = line.split(',');
    if (parts.length < 2) continue;
    var dbh = parseFloat(parts[0]);
    var height = parseFloat(parts[1]);
    var count = parts.length >= 3 ? parseInt(parts[2]) : 1;
    if (isNaN(dbh) || isNaN(height) || dbh <= 0 || height <= 0 || count < 1) continue;
    if (imported >= maxRows) { truncated = true; break; }
    ForestCalc.batchRows.push({ speciesIdx: speciesIdx, dbh: dbh, height: height, count: count });
    imported++;
  }
  ForestCalc.renderBatch();
  if (truncated) {
    ForestCalc.showToast('已导入前 ' + maxRows + ' 行，超出部分已忽略', 'warn');
  } else {
    ForestCalc.showToast('成功导入 ' + imported + ' 行数据', 'success');
  }
  document.getElementById('csvTextarea').value = '';
  document.getElementById('csvImportPanel').style.display = 'none';
};

ForestCalc.renderBatch = function() {
  // v1.7.5: 性能监控
  var perfStart = performance.now();
  var tbody = document.getElementById('batchBody');
  if (ForestCalc.batchRows.length === 0) {
    tbody.innerHTML = '<tr><td colspan="11" style="padding:32px;color:#8b7355;">暂无数据 — 请添加树木</td></tr>';
    document.getElementById('batchSummary').style.display = 'none';
    ForestCalc._batchRowPool = [];
    return;
  }

  // v1.7.6: 虚拟滚动（行数 > 50 时启用）
  var enableVirtualScroll = ForestCalc.batchRows.length > 50;
  ForestCalc._virtualScrollEnabled = enableVirtualScroll;

  if (enableVirtualScroll) {
    ForestCalc._renderVirtualBatch();
  } else {
    // --- 原有增量更新逻辑 ---
    ForestCalc._renderIncrementalBatch();
  }

  document.getElementById('batchSummary').style.display = 'none';
  var countEl = document.getElementById('batchRowCount');
  if (countEl) countEl.textContent = '共 ' + ForestCalc.batchRows.length + ' 行' + (enableVirtualScroll ? ' (虚拟滚动已启用)' : '');

  // v1.7.5: 收集性能数据
  var elapsed = performance.now() - perfStart;
  ForestCalc._logPerf('renderBatch', elapsed);
};

// ========== v1.7.6: 虚拟滚动 — 增量渲染 ==========
// 原有增量更新逻辑（行数 ≤ 50 时使用）
ForestCalc._renderIncrementalBatch = function() {
  var tbody = document.getElementById('batchBody');
  var pool = ForestCalc._batchRowPool || (ForestCalc._batchRowPool = []);
  var speciesList = ForestCalc.SPECIES;
  var frag = document.createDocumentFragment();

  for (var i = 0; i < ForestCalc.batchRows.length; i++) {
    var r = ForestCalc.batchRows[i];
    var tr = pool[i];
    var needRebuild = !tr || tr.dataset.idx != i || tr.dataset.species != r.speciesIdx || tr.dataset.dbh != r.dbh || tr.dataset.height != r.height || tr.dataset.count != (r.count||1);

    if (needRebuild) {
      tr = document.createElement('tr');
      tr.dataset.idx = i;
      tr.dataset.species = r.speciesIdx;
      tr.dataset.dbh = r.dbh;
      tr.dataset.height = r.height;
      tr.dataset.count = r.count || 1;

      var vv = r._vol, sp = r._spec, ns = r._nonSpec, fl = r._fuel, wa = r._waste;
      var volStr = (vv != null) ? vv.toFixed(4) : '—';
      var specStr = (sp != null) ? sp.toFixed(4) : '—';
      var nsStr = (ns != null) ? ns.toFixed(4) : '—';
      var flStr = (fl != null) ? fl.toFixed(4) : '—';
      var waStr = (wa != null) ? wa.toFixed(4) : '—';

      var speciesOptions = '';
      for (var si = 0; si < speciesList.length; si++) {
        speciesOptions += '<option value="' + si + '"' + (si===r.speciesIdx?' selected':'') + '>' + speciesList[si].name + '</option>';
      }

      var moveUp = (i > 0) ? '<button class="btn btn-outline btn-sm" onclick="ForestCalc.moveBatchRow(' + i + ',-1)" title="上移">↑</button>' : '';
      var moveDown = (i < ForestCalc.batchRows.length - 1) ? '<button class="btn btn-outline btn-sm" onclick="ForestCalc.moveBatchRow(' + i + ',1)" title="下移">↓</button>' : '';
      var actions = moveUp + moveDown + '<button class="btn btn-outline btn-sm" onclick="ForestCalc.copyBatchRow(' + i + ')" title="复制此行">📋</button> <button class="btn btn-danger btn-sm" onclick="ForestCalc._pushUndo();ForestCalc.batchRows.splice(' + i + ',1);ForestCalc.renderBatch();">✕</button>';

      tr.innerHTML =
        '<td>' + (i+1) + '</td>' +
        '<td><select aria-label="选择树种">' + speciesOptions + '</select></td>' +
        '<td><input type="number" step="0.1" value="' + r.dbh + '" aria-label="胸径(cm)"></td>' +
        '<td><input type="number" step="0.1" value="' + r.height + '" aria-label="树高(m)"></td>' +
        '<td><input type="number" min="1" step="1" value="' + (r.count||1) + '" style="width:48px;padding:5px;text-align:center;" aria-label="株数"></td>' +
        '<td>' + volStr + '</td>' +
        '<td>' + specStr + '</td>' +
        '<td>' + nsStr + '</td>' +
        '<td>' + flStr + '</td>' +
        '<td>' + waStr + '</td>' +
        '<td>' + actions + '</td>';

      (function(idx, row) {
        var sel = row.cells[1].firstChild;
        sel.onchange = function() {
          ForestCalc._pushUndo();
          ForestCalc.batchRows[idx].speciesIdx = parseInt(this.value);
          ForestCalc.batchRows[idx]._vol = null;
          if (document.getElementById('batchSummary').style.display !== 'none') ForestCalc.calcBatch();
          else ForestCalc.renderBatch();
        };
        var dbhInput = row.cells[2].firstChild;
        dbhInput.onchange = function() {
          ForestCalc._pushUndo();
          ForestCalc.batchRows[idx].dbh = parseFloat(this.value) || '';
          ForestCalc.batchRows[idx]._vol = null;
          ForestCalc.renderBatch();
        };
        dbhInput.onblur = function() { ForestCalc.autoFillBatchHeight(idx); };
        var hInput = row.cells[3].firstChild;
        hInput.onchange = function() {
          ForestCalc._pushUndo();
          ForestCalc.batchRows[idx].height = parseFloat(this.value) || '';
          ForestCalc.batchRows[idx]._vol = null;
          ForestCalc.renderBatch();
        };
        var cntInput = row.cells[4].firstChild;
        cntInput.onchange = function() {
          ForestCalc._pushUndo();
          var c = parseInt(this.value) || 1;
          ForestCalc.batchRows[idx].count = c;
          ForestCalc.batchRows[idx]._vol = null;
          ForestCalc.renderBatch();
        };
      })(i, tr);

      pool[i] = tr;
    }
    frag.appendChild(tr);
  }

  if (pool.length > ForestCalc.batchRows.length) {
    pool.length = ForestCalc.batchRows.length;
  }

  tbody.innerHTML = '';
  tbody.appendChild(frag);
};

// ========== v1.7.6: 虚拟滚动 — 可视区域渲染 ==========
// 虚拟滚动核心函数（行数 > 50 时使用）
ForestCalc._renderVirtualBatch = function() {
  var tbody = document.getElementById('batchBody');
  var tableWrap = tbody.closest('.table-wrap');
  var ROW_HEIGHT = 52;
  var BUFFER_ROWS = 5;
  var totalRows = ForestCalc.batchRows.length;
  var viewportHeight = tableWrap.clientHeight || 600;
  var visibleCount = Math.ceil(viewportHeight / ROW_HEIGHT) + BUFFER_ROWS * 2;
  var scrollTop = tableWrap.scrollTop || 0;
  var startIndex = Math.max(0, Math.floor(scrollTop / ROW_HEIGHT) - BUFFER_ROWS);
  var endIndex = Math.min(totalRows, startIndex + visibleCount);

  // 确保池子足够大
  var pool = ForestCalc._batchRowPool || (ForestCalc._batchRowPool = []);
  var speciesList = ForestCalc.SPECIES;

  // 检查并更新/创建可视区域的行
  for (var i = startIndex; i < endIndex; i++) {
    var r = ForestCalc.batchRows[i];
    var tr = pool[i];

    // 判断是否需要重建
    var needRebuild = !tr || tr.dataset.idx != i || tr.dataset.species != r.speciesIdx || tr.dataset.dbh != r.dbh || tr.dataset.height != r.height || tr.dataset.count != (r.count||1);

    if (needRebuild) {
      tr = document.createElement('tr');
      tr.dataset.idx = i;
      tr.dataset.species = r.speciesIdx;
      tr.dataset.dbh = r.dbh;
      tr.dataset.height = r.height;
      tr.dataset.count = r.count || 1;
      tr.style.position = 'absolute';
      tr.style.left = '0';
      tr.style.top = (i * ROW_HEIGHT) + 'px';
      tr.style.width = '100%';
      tr.style.display = 'table-row';
      tr.style.height = ROW_HEIGHT + 'px';

      var vv = r._vol, sp = r._spec, ns = r._nonSpec, fl = r._fuel, wa = r._waste;
      var volStr = (vv != null) ? vv.toFixed(4) : '—';
      var specStr = (sp != null) ? sp.toFixed(4) : '—';
      var nsStr = (ns != null) ? ns.toFixed(4) : '—';
      var flStr = (fl != null) ? fl.toFixed(4) : '—';
      var waStr = (wa != null) ? wa.toFixed(4) : '—';

      var speciesOptions = '';
      for (var si = 0; si < speciesList.length; si++) {
        speciesOptions += '<option value="' + si + '"' + (si===r.speciesIdx?' selected':'') + '>' + speciesList[si].name + '</option>';
      }

      var moveUp = (i > 0) ? '<button class="btn btn-outline btn-sm" onclick="ForestCalc.moveBatchRow(' + i + ',-1)" title="上移">↑</button>' : '';
      var moveDown = (i < ForestCalc.batchRows.length - 1) ? '<button class="btn btn-outline btn-sm" onclick="ForestCalc.moveBatchRow(' + i + ',1)" title="下移">↓</button>' : '';
      var actions = moveUp + moveDown + '<button class="btn btn-outline btn-sm" onclick="ForestCalc.copyBatchRow(' + i + ')" title="复制此行">📋</button> <button class="btn btn-danger btn-sm" onclick="ForestCalc._pushUndo();ForestCalc.batchRows.splice(' + i + ',1);ForestCalc.renderBatch();">✕</button>';

      tr.innerHTML =
        '<td>' + (i+1) + '</td>' +
        '<td><select aria-label="选择树种">' + speciesOptions + '</select></td>' +
        '<td><input type="number" step="0.1" value="' + r.dbh + '" aria-label="胸径(cm)"></td>' +
        '<td><input type="number" step="0.1" value="' + r.height + '" aria-label="树高(m)"></td>' +
        '<td><input type="number" min="1" step="1" value="' + (r.count||1) + '" style="width:48px;padding:5px;text-align:center;" aria-label="株数"></td>' +
        '<td>' + volStr + '</td>' +
        '<td>' + specStr + '</td>' +
        '<td>' + nsStr + '</td>' +
        '<td>' + flStr + '</td>' +
        '<td>' + waStr + '</td>' +
        '<td>' + actions + '</td>';

      (function(idx, row) {
        var sel = row.cells[1].firstChild;
        sel.onchange = function() {
          ForestCalc._pushUndo();
          ForestCalc.batchRows[idx].speciesIdx = parseInt(this.value);
          ForestCalc.batchRows[idx]._vol = null;
          if (document.getElementById('batchSummary').style.display !== 'none') ForestCalc.calcBatch();
          else ForestCalc.renderBatch();
        };
        var dbhInput = row.cells[2].firstChild;
        dbhInput.onchange = function() {
          ForestCalc._pushUndo();
          ForestCalc.batchRows[idx].dbh = parseFloat(this.value) || '';
          ForestCalc.batchRows[idx]._vol = null;
          ForestCalc.renderBatch();
        };
        dbhInput.onblur = function() { ForestCalc.autoFillBatchHeight(idx); };
        var hInput = row.cells[3].firstChild;
        hInput.onchange = function() {
          ForestCalc._pushUndo();
          ForestCalc.batchRows[idx].height = parseFloat(this.value) || '';
          ForestCalc.batchRows[idx]._vol = null;
          ForestCalc.renderBatch();
        };
        var cntInput = row.cells[4].firstChild;
        cntInput.onchange = function() {
          ForestCalc._pushUndo();
          var c = parseInt(this.value) || 1;
          ForestCalc.batchRows[idx].count = c;
          ForestCalc.batchRows[idx]._vol = null;
          ForestCalc.renderBatch();
        };
      })(i, tr);

      pool[i] = tr;
    } else {
      // 只更新位置
      tr.style.top = (i * ROW_HEIGHT) + 'px';
    }

    // 确保行在 DOM 中
    if (!tr.parentNode) {
      tbody.appendChild(tr);
    }
  }

  // 移除可视区域外的行
  for (var j = 0; j < pool.length; j++) {
    if (j < startIndex || j >= endIndex) {
      if (pool[j] && pool[j].parentNode) {
        pool[j].parentNode.removeChild(pool[j]);
      }
    }
  }

  // 添加占位 div 模拟总高度
  var spacer = document.getElementById('virtualSpacer');
  if (!spacer) {
    spacer = document.createElement('div');
    spacer.id = 'virtualSpacer';
    spacer.className = 'virtual-scroll-spacer';
    tbody.appendChild(spacer);
  }
  spacer.style.height = (totalRows * ROW_HEIGHT) + 'px';
};

// ========== v1.7.6: 绑定滚动事件 ==========
ForestCalc._bindVirtualScroll = function() {
  var tbody = document.getElementById('batchBody');
  var tableWrap = tbody.closest('.table-wrap');
  if (!tableWrap || tableWrap._virtualScrollBound) return;

  tableWrap._virtualScrollBound = true;
  var scrollTimer = null;

  tableWrap.addEventListener('scroll', function() {
    if (ForestCalc._virtualScrollEnabled) {
      if (scrollTimer) clearTimeout(scrollTimer);
      scrollTimer = setTimeout(function() {
        ForestCalc._renderVirtualBatch();
      }, 16); // ~60fps
    }
  });

  window.addEventListener('resize', function() {
    if (ForestCalc._virtualScrollEnabled) {
      if (scrollTimer) clearTimeout(scrollTimer);
      scrollTimer = setTimeout(function() {
        ForestCalc._renderVirtualBatch();
      }, 100);
    }
  });
};

ForestCalc.calcBatch = function() {
  // v1.7.5: 性能监控
  var perfStart = performance.now();
  var tV=0, tS=0, tN=0, tF=0, tW=0, cnt=0, validCnt=0;
  // 提前检测自定义出材率，避免循环内重复读取 DOM
  var yTotalVal = parseFloat(document.getElementById('yTotal').value);
  var isCustomYield = !isNaN(yTotalVal) && yTotalVal > 0 && yTotalVal <= 1;
  ForestCalc.batchRows.forEach(function(r) {
    if (!r.dbh || r.dbh<=0 || !r.height || r.height<=0) return;
    var s = ForestCalc.SPECIES[r.speciesIdx];
    if (s.a === 0) return; // skip species with no formula
    var v = ForestCalc.calcVolume(s, r.dbh, r.height);
    // 与 calcSingle 保持一致：直接传参调用 calcYieldRates，解耦 DOM
    var yr = ForestCalc.calcYieldRates(s, isCustomYield ? yTotalVal : null);
    var y = {
      spec: v * yr.spec,
      nonSpec: v * yr.nonSpec,
      fuel: v * yr.fuel,
      waste: v * yr.waste,
      econRate: yr.spec + yr.nonSpec,
      dynamic: !yr.custom
    };
    var c = r.count || 1;
    r._vol=v*c; r._spec=y.spec*c; r._nonSpec=y.nonSpec*c; r._fuel=y.fuel*c; r._waste=y.waste*c;
    tV+=v*c; tS+=y.spec*c; tN+=y.nonSpec*c; tF+=y.fuel*c; tW+=y.waste*c;
    validCnt+=c;
    cnt++;
  });
  ForestCalc.renderBatch();
  if (cnt===0) { ForestCalc.showToast('请至少输入一株有效树木。', 'warn'); return; }

  var sb = document.getElementById('batchSummary');
  sb.style.display = '';
  var totalEconBatch = tS + tN;
  var areaB = parseFloat(document.getElementById('batchAreaInput').value) || 0;
  var areaRows = '';
  if (areaB > 0) {
    areaRows =
    '<tr><td colspan="11">' +
    '<div class="area-hero" style="margin-top:10px;">' +
      '<div class="area-title">亩均统计（' + areaB.toFixed(1) + ' 亩）</div>' +
      '<div class="area-grid">' +
        '<div class="area-stat"><span class="big">' + (tV/areaB).toFixed(4) + '</span> m³/亩 蓄积</div>' +
        '<div class="area-stat"><span class="big">' + (tS/areaB).toFixed(4) + '</span> m³/亩 规格材</div>' +
        '<div class="area-stat"><span class="big">' + (tN/areaB).toFixed(4) + '</span> m³/亩 非规格材</div>' +
        '<div class="area-stat"><span class="big">' + (tF/areaB).toFixed(4) + '</span> m³/亩 薪材</div>' +
        '<div class="area-stat"><span class="big">' + (tW/areaB).toFixed(4) + '</span> m³/亩 废材</div>' +
      '</div>' +
    '</div>' +
    '</td></tr>';
  }
  // 公顷模式合计行
  var densityBatch = parseInt(document.getElementById('density').value) || 0;
  var hectareRow = '';
  if (densityBatch > 0 && cnt > 0) {
    var avgVol = validCnt > 0 ? tV / validCnt : 0;
    var avgSpec = validCnt > 0 ? tS / validCnt : 0;
    var avgNonSpec = validCnt > 0 ? tN / validCnt : 0;
    var avgFuel = validCnt > 0 ? tF / validCnt : 0;
    var avgWaste = validCnt > 0 ? tW / validCnt : 0;
    var haVol = avgVol * densityBatch;
    var haSpec = avgSpec * densityBatch;
    var haNonSpec = avgNonSpec * densityBatch;
    var haFuel = avgFuel * densityBatch;
    var haWaste = avgWaste * densityBatch;
    hectareRow =
    '<tr class="summary-row" style="background:rgba(196,165,110,0.12);font-weight:bold;">' +
      '<td colspan="5">公顷合计（' + densityBatch + ' 株/公顷）</td>' +
      '<td>' + haVol.toFixed(3) + ' m³</td><td>' + haSpec.toFixed(3) + ' m³</td><td>' + haNonSpec.toFixed(3) + ' m³</td><td>' + haFuel.toFixed(3) + ' m³</td><td>' + haWaste.toFixed(3) + ' m³</td><td></td>' +
    '</tr>';
  }
  sb.innerHTML =
    '<tr class="summary-row">' +
      '<td colspan="5">采伐合计（' + validCnt + ' 株，' + cnt + ' 行）</td>' +
      '<td>' + tV.toFixed(4) + ' m³</td><td>' + tS.toFixed(4) + ' m³</td><td>' + tN.toFixed(4) + ' m³</td><td>' + tF.toFixed(4) + ' m³</td><td>' + tW.toFixed(4) + ' m³</td><td></td>' +
    '</tr>' +
    '<tr class="summary-row">' +
      '<td colspan="5">经济材总计</td>' +
      '<td colspan="2" style="color:var(--pine);font-size:16px;">' + totalEconBatch.toFixed(4) + ' m³</td>' +
      '<td colspan="2">综合出材率</td>' +
      '<td colspan="2">' + (tV>0?(totalEconBatch/tV*100).toFixed(1):0) + '%</td>' +
    '</tr>' +
    areaRows +
    hectareRow;

  // 统计摘要
  var validRows = ForestCalc.batchRows.filter(function(r) { return r._vol != null; });
  if (validRows.length > 1) {
    var vols = [], specs = [], nonSpecs = [], fuels = [], wastes = [];
    validRows.forEach(function(r) {
      vols.push(r._vol); specs.push(r._spec); nonSpecs.push(r._nonSpec); fuels.push(r._fuel); wastes.push(r._waste);
    });
    var avg = function(arr) { return arr.reduce(function(a,b) { return a+b; }, 0) / arr.length; };
    var min = function(arr) { return Math.min.apply(null, arr); };
    var max = function(arr) { return Math.max.apply(null, arr); };

    sb.innerHTML +=
    '<tr><td colspan="11">' +
    '<div style="margin-top:10px;padding:8px;background:rgba(196,165,110,0.06);border-radius:6px;">' +
    '<h5 style="margin:0 0 6px 0;">📊 统计摘要 (' + validRows.length + ' 条有效数据)</h5>' +
    '<table style="width:100%;font-size:12px;">' +
    '<tr style="border-bottom:1px solid rgba(196,165,110,0.15);"><th></th><th>单株材积</th><th>规格材</th><th>非规格材</th><th>薪材</th><th>废材</th></tr>' +
    '<tr><td>平均</td><td>' + avg(vols).toFixed(4) + '</td><td>' + avg(specs).toFixed(4) + '</td><td>' + avg(nonSpecs).toFixed(4) + '</td><td>' + avg(fuels).toFixed(4) + '</td><td>' + avg(wastes).toFixed(4) + '</td></tr>' +
    '<tr><td>最小</td><td>' + min(vols).toFixed(4) + '</td><td>' + min(specs).toFixed(4) + '</td><td>' + min(nonSpecs).toFixed(4) + '</td><td>' + min(fuels).toFixed(4) + '</td><td>' + min(wastes).toFixed(4) + '</td></tr>' +
    '<tr><td>最大</td><td>' + max(vols).toFixed(4) + '</td><td>' + max(specs).toFixed(4) + '</td><td>' + max(nonSpecs).toFixed(4) + '</td><td>' + max(fuels).toFixed(4) + '</td><td>' + max(wastes).toFixed(4) + '</td></tr>' +
    '</table></div>' +
    '</td></tr>';
  }

  // 按树种分组统计
  var groups = {};
  validRows.forEach(function(r) {
    var sidx = r.speciesIdx;
    if (!groups[sidx]) groups[sidx] = { count: 0, totalVolume: 0, totalSpec: 0, totalNonSpec: 0, totalFuel: 0, totalWaste: 0 };
    groups[sidx].count += (r.count || 1);
    groups[sidx].totalVolume += r._vol;
    groups[sidx].totalSpec += r._spec;
    groups[sidx].totalNonSpec += r._nonSpec;
    groups[sidx].totalFuel += r._fuel;
    groups[sidx].totalWaste += r._waste;
  });
  var groupKeys = Object.keys(groups);
  if (groupKeys.length > 0) {
    var ghtml = '<tr><td colspan="11">' +
    '<div style="margin-top:10px;padding:8px;background:rgba(196,165,110,0.06);border-radius:6px;">' +
    '<h5 style="margin:0 0 6px 0;">按树种分组</h5>' +
    '<table style="width:100%;font-size:12px;">' +
    '<tr style="border-bottom:1px solid rgba(196,165,110,0.15);"><th>树种</th><th>株数</th><th>总蓄积(m³)</th><th>规格材(m³)</th><th>非规格材(m³)</th><th>薪材(m³)</th><th>废材(m³)</th></tr>';
    groupKeys.forEach(function(key) {
      var g = groups[key];
      var sp = ForestCalc.SPECIES[key];
      ghtml += '<tr><td>' + (sp ? sp.name : '未知') + '</td><td>' + g.count + '</td><td>' + g.totalVolume.toFixed(4) + '</td><td>' + g.totalSpec.toFixed(4) + '</td><td>' + g.totalNonSpec.toFixed(4) + '</td><td>' + g.totalFuel.toFixed(4) + '</td><td>' + g.totalWaste.toFixed(4) + '</td></tr>';
    });
    ghtml += '</table></div></td></tr>';
    sb.innerHTML += ghtml;
  }

  sb.scrollIntoView({ behavior: 'smooth' });

  // v1.7.5: 收集性能数据
  var elapsed = performance.now() - perfStart;
  ForestCalc._logPerf('calcBatch', elapsed);
};

// ========== 数据面板渲染 ==========
ForestCalc.renderDataPanel = function() {
  var div = document.getElementById('dataPanel');
  var h = '<div class="table-wrap src-table"><table><thead><tr><th>树种</th><th>a</th><th>b</th><th>c</th><th>公式来源</th><th>验证</th><th>出材率参考</th></tr></thead><tbody>';
  ForestCalc.SPECIES.forEach(function(s) {
    var dot = s.reliability==='high'?'conf-high':s.reliability==='medium'?'conf-medium':'conf-low';
    var lbl = s.reliability==='high'?'省标':(s.reliability==='medium'?'部标':(s.reliability==='low'?'近似':''));
    h += '<tr>' +
      '<td><strong>' + s.name + '</strong><br><small style="color:#8b7355;">' + s.latin + '</small></td>' +
      '<td>' + (s.a||'—') + '</td><td>' + (s.b||'—') + '</td><td>' + (s.c||'—') + '</td>' +
      '<td style="font-size:11px;">' + s.source + '</td>' +
      '<td><span class="confidence-dot ' + dot + '"></span>' + (lbl||'—') + '</td>' +
      '<td style="font-size:11px;">' + (s.a===0?'—':'规格'+(s.yieldRates.spec*100).toFixed(0)+'% 非规格'+(s.yieldRates.nonSpec*100).toFixed(0)+'%<br>薪材'+(s.yieldRates.fuel*100).toFixed(0)+'% 废材'+(s.yieldRates.waste*100).toFixed(0)+'%') + '</td>' +
    '</tr>';
  });
  h += '</tbody></table></div>';

  h +=
    '<div class="callout callout-warn">' +
      '<strong>验证说明：</strong><br>' +
      '马尾松公式已验证：D=20cm H=15.5m → V=0.256m³，与 DB51/T 1466-2012 标准查表值一致。<br>' +
      '柏木公式参数来自 DB51/T 1467-2012 标称值。D=20 H=15.5 → 0.205m³，与标准查表值一致。<br>' +
      '其余树种来自 LY208-77 部标或四川滇西北阔叶公式，精度可接受但非四川本地编表。' +
    '</div>' +
    '<div class="callout callout-info">' +
      '<strong>已获取的标准文件：</strong><br>' +
      'DB51/T 1466-2012 马尾松 &nbsp;|&nbsp; DB51/T 2918-2022 森林经营规程 &nbsp;|&nbsp; ' +
      'DB52/T 703-2011 马尾松(黔) &nbsp;|&nbsp; DB52/T 822-2013 软阔(黔) &nbsp;|&nbsp; ' +
      'DB52/T 826-2013 硬阔(黔)<br>' +
      'DB35/T 1823-2019 福建主要树种 &nbsp;|&nbsp; ' +
      'DB53/T 1422.1-2025 云南松(滇) &nbsp;|&nbsp; ' +
      'DB34/T 3345-2019 马尾松(皖)<br>' +
      'GB/T 4814-2013 原木材积表 &nbsp;|&nbsp; LY/T 2102-2013 编制技术规程' +
    '</div>' +
    '<div class="callout callout-info">' +
      '<strong>跨省公式对照（福建 DB35/T 1823-2019）：</strong><br>' +
      '杉木: V=0.0000706094×D^1.801671×H^0.997998 &nbsp;|&nbsp; ' +
      '马尾松: V=0.000070728×D^1.874518×H^0.908949<br>' +
      '阔叶树: V=0.0000685634×D^1.933221×H^0.867885 &nbsp;|&nbsp; ' +
      '其他针叶: V=0.000069978×D^1.8660492×H^0.905254' +
    '</div>';
  div.innerHTML = h;
};

// ========== 自定义公式保存/加载/删除 ==========
ForestCalc.saveCustom = function() {
  var name = document.getElementById('cName').value.trim();
  var a = parseFloat(document.getElementById('cA').value);
  var b = parseFloat(document.getElementById('cB').value);
  var c = parseFloat(document.getElementById('cC').value);
  if (!name || isNaN(a) || isNaN(b) || isNaN(c)) { ForestCalc.showToast('请填写树种名称和 a,b,c 三个系数。', 'warn'); return; }
  var saved = ForestCalc.loadSavedCustoms();
  saved.push({ name: name, a: a, b: b, c: c, time: new Date().toLocaleString() });
  if (saved.length > 20) saved.shift();
  ForestCalc.saveCustomToStorage(saved);
  ForestCalc.renderSavedList();
  ForestCalc.showToast('已保存: ' + name, 'success');
};

ForestCalc.applySaved = function(idx) {
  var saved = ForestCalc.loadSavedCustoms();
  var s = saved[idx];
  if (!s) return;
  document.getElementById('cName').value = s.name;
  document.getElementById('cA').value = s.a;
  document.getElementById('cB').value = s.b;
  document.getElementById('cC').value = s.c;
  document.getElementById('customFields').style.display = 'block';
  document.querySelectorAll('.yield-toggle')[1].innerHTML = '自定义树种/公式 ▾ 点击收起';
};

ForestCalc.deleteSaved = function(idx) {
  var saved = ForestCalc.loadSavedCustoms();
  saved.splice(idx, 1);
  ForestCalc.saveCustomToStorage(saved);
  ForestCalc.renderSavedList();
};

ForestCalc.renderSavedList = function() {
  var saved = ForestCalc.loadSavedCustoms();
  var container = document.getElementById('savedCustoms');
  var list = document.getElementById('savedList');
  if (saved.length === 0) { container.style.display = 'none'; return; }
  container.style.display = 'block';
  list.innerHTML = saved.map(function(s, i) {
    return '<span style="cursor:pointer;color:var(--pine);margin-right:12px;" onclick="ForestCalc.applySaved(' + i + ')" title="点击应用">' +
      ForestCalc.escapeHTML(s.name) + '</span>' +
      '<span style="cursor:pointer;color:var(--danger);font-size:10px;" onclick="ForestCalc.deleteSaved(' + i + ')">✕</span>';
  }).join(' | ');
};

// ========== 计算历史渲染 ==========
ForestCalc.renderHistory = function() {
  var hist = ForestCalc.loadHistory();
  document.getElementById('histCount').textContent = hist.length;
  var panel = document.getElementById('histPanel');
  if (hist.length === 0) { panel.innerHTML = '<span style="color:#8b7355;">暂无记录</span>'; return; }
  panel.innerHTML = '<table style="font-size:11px;width:100%;"><thead><tr><th>时间</th><th>树种</th><th>D(cm)</th><th>H(m)</th><th>株</th><th>蓄积(m³)</th><th>经济材(m³)</th></tr></thead><tbody>' +
    hist.map(function(h) { return '<tr><td>'+h.time+'</td><td>'+ForestCalc.escapeHTML(h.species)+'</td><td>'+h.dbh+'</td><td>'+h.height+'</td><td>'+h.count+'</td><td>'+h.vol+'</td><td>'+h.econ+'</td></tr>'; }).join('') +
    '</tbody></table>';
};

// ========== 折叠/展开控制 ==========
ForestCalc.toggleHistory = function() {
  var panel = document.getElementById('histPanel');
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
};

ForestCalc.toggleCustom = function() {
  var el = document.getElementById('customFields');
  var show = el.style.display === 'none';
  el.style.display = show ? 'block' : 'none';
  document.querySelectorAll('.yield-toggle')[1].innerHTML = show ? '自定义树种/公式 ▾ 点击收起' : '自定义树种/公式 ▸ 点击展开';
};

ForestCalc.toggleYield = function() {
  var el = document.getElementById('yieldFields');
  var show = el.style.display === 'none';
  el.style.display = show ? 'block' : 'none';
  document.querySelector('.yield-toggle').innerHTML = show ? '综合出材率 ▾ 点击收起' : '综合出材率 ▸ 点击自定义';
};

ForestCalc.toggleData = function(el) {
  el.classList.toggle('open');
  el.nextElementSibling.classList.toggle('open');
};

// ========== 清空历史 ==========
ForestCalc.clearHistoryUI = function() {
  ForestCalc.showConfirm('确定清空所有计算历史？', function() { ForestCalc.clearHistory(); ForestCalc.renderHistory(); });
};

// ========== 暗色主题切换 ==========
ForestCalc.toggleTheme = function() {
  document.body.classList.toggle('dark');
  var isDark = document.body.classList.contains('dark');
  document.getElementById('themeToggle').textContent = isDark ? '☀️' : '🌙';
  localStorage.setItem('fc_theme', isDark ? 'dark' : 'light');
};

// ========== 批量结果 CSV 导出 ==========
ForestCalc.exportBatchCSV = function() {
  var rows = ForestCalc.batchRows;
  var validRows = rows.filter(function(r) { return r._vol != null; });
  if (validRows.length === 0) { ForestCalc.showToast('请先计算批量数据', 'warn'); return; }
  
  var csv = '\uFEFF序号,树种,胸径(cm),树高(m),株数,蓄积量(m³),规格材(m³),非规格材(m³),薪材(m³),废材(m³)\n';
  validRows.forEach(function(r, i) {
    var s = ForestCalc.SPECIES ? ForestCalc.SPECIES[r.speciesIdx] : null;
    var name = s ? s.name : '未知';
    csv += (i+1) + ',' + name + ',' + r.dbh + ',' + r.height + ',' + (r.count || 1) + ',' + r._vol.toFixed(4) + ',' + r._spec.toFixed(4) + ',' + r._nonSpec.toFixed(4) + ',' + r._fuel.toFixed(4) + ',' + r._waste.toFixed(4) + '\n';
  });
  
  var blob = new Blob([csv], {type: 'text/csv;charset=utf-8;'});
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = '采伐计算汇总_' + new Date().toISOString().slice(0,10) + '.csv';
  a.click();
  URL.revokeObjectURL(url);
};

// ========== 收方表 CSV 导出 ==========
ForestCalc.exportYieldCSV = function() {
  var data = ForestCalc._yieldTableData;
  if (!data || !data.rows || data.rows.length === 0) { ForestCalc.showToast('请先生成收方表', 'warn'); return; }
  
  var csv = '\uFEFF胸径(cm),树高(m),材积(m³),规格材(m³),非规格材(m³),薪材(m³),废材(m³),经济材率\n';
  data.rows.forEach(function(r) {
    csv += r.dbh + ',' + r.height + ',' + r.volume.toFixed(4) + ',' + r.specVol.toFixed(4) + ',' + r.nonSpecVol.toFixed(4) + ',' + r.fuelVol.toFixed(4) + ',' + r.wasteVol.toFixed(4) + ',' + (r.econRate * 100).toFixed(1) + '%\n';
  });
  
  var blob = new Blob([csv], {type: 'text/csv;charset=utf-8;'});
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  var spName = data.species ? data.species.name.replace(/[\\/:*?"<>|]/g, '_') : '未知';
  a.download = '收方表_' + spName + '_' + new Date().toISOString().slice(0,10) + '.csv';
  a.click();
  URL.revokeObjectURL(url);
};

// ========== 跨省标准对比 ==========
ForestCalc.showCompare = function() {
  var d = parseFloat(document.getElementById('dbhInput').value) || 20;
  var h = parseFloat(document.getElementById('heightInput').value) || 15;

  // 按树种 groupKey 动态分组，不再硬编码 ID 列表
  var groups = {};
  ForestCalc.SPECIES.forEach(function(s) {
    if (!s.id) return;
    // 从 id 中提取分组键：取第一个短横线前的部分，或完整 id
    var key = s.id.split('-')[0];
    // 合并同科/同属：masson-pine 和 masson-pine-db51 都归为 masson-pine
    var groupKey = s.id;
    if (s.id.indexOf('masson-pine') === 0) groupKey = 'masson-pine-group';
    else if (s.id.indexOf('chinese-fir') === 0) groupKey = 'chinese-fir-group';
    else if (s.id.indexOf('cypress') === 0) groupKey = 'cypress-group';
    else if (s.id.indexOf('soft-') === 0) groupKey = 'soft-broad-group';
    else if (s.id.indexOf('broadleaf') === 0) groupKey = 'broadleaf-group';
    else if (s.id.indexOf('other-conifer') === 0) groupKey = 'other-conifer-group';
    else if (s.id.indexOf('yunnan-pine') === 0) groupKey = 'yunnan-pine-group';
    else groupKey = s.id;

    if (!groups[groupKey]) groups[groupKey] = { title: s.name.split('(')[0] + ' (多省)', items: [] };
    groups[groupKey].items.push(s);
  });

  var html = '<div style="margin-top:16px;"><h4>📊 跨省标准对比 (D=' + d + 'cm H=' + h + 'm)</h4>';
  Object.keys(groups).forEach(function(key) {
    var g = groups[key];
    html += '<table style="width:100%;margin-bottom:10px;border-collapse:collapse;font-size:13px;">';
    html += '<tr style="background:rgba(196,165,110,0.08);"><th colspan="5" style="text-align:left;padding:6px 8px;">' + g.title + '</th></tr>';
    html += '<tr style="border-bottom:2px solid rgba(196,165,110,0.3);color:var(--wood);">';
    html += '<th style="text-align:left;">标准</th><th>材积(m³)</th><th>经济材率</th><th>规格材(m³)</th><th style="text-align:left;">来源</th></tr>';

    g.items.forEach(function(s) {
      var vol = ForestCalc.calcVolume(s, d, h);
      if (vol === null) return;
      var y = ForestCalc.calcYield(s, vol, d, h);

      html += '<tr style="border-bottom:1px solid rgba(196,165,110,0.1);">';
      html += '<td>' + s.name + '</td>';
      html += '<td>' + vol.toFixed(4) + '</td>';
      html += '<td>' + (y.econRate * 100).toFixed(1) + '%</td>';
      html += '<td>' + y.spec.toFixed(4) + '</td>';
      var src = (s.source || '').replace('DB51/T ', 'DB51/').replace('DB52/T ', 'DB52/').replace('DB35/T ', 'DB35/').replace('DB34/T ', 'DB34/');
      html += '<td style="font-size:11px;color:var(--wood-dark);">' + src.substring(0, 28) + '</td>';
      html += '</tr>';
    });

    html += '</table>';
  });
  html += '<small style="color:var(--wood);">注: 材积差异来自各省标准系数不同，经济材率来自树种级 econBasePct</small></div>';

  var container = document.getElementById('comparePanel');
  container.innerHTML = html;
  container.style.display = '';
  document.getElementById('batchCard').scrollIntoView({ behavior: 'smooth' });
};

// ========== 收方表生成 ==========
ForestCalc.showYieldTable = function() {
  var panel = document.getElementById('yieldTableOptions');
  if (panel && (panel.style.display === 'none' || panel.style.display === '')) {
    panel.style.display = 'block';
  }

  var speciesId = ForestCalc.SPECIES[document.getElementById('speciesSelect').value]?.id;
  if (!speciesId) { ForestCalc.showToast('请先选择树种', 'warn'); return; }

  var dMin = parseInt(document.getElementById('dMinYield')?.value);
  if (!dMin || isNaN(dMin)) {
    var selSpecies = ForestCalc.SPECIES[document.getElementById('speciesSelect').value];
    dMin = (selSpecies && selSpecies.yieldDMin) ? selSpecies.yieldDMin : 6;
  }
  var dMax = parseInt(document.getElementById('dMaxYield')?.value);
  if (!dMax || isNaN(dMax)) {
    var selSpecies = ForestCalc.SPECIES[document.getElementById('speciesSelect').value];
    dMax = (selSpecies && selSpecies.yieldDMax) ? selSpecies.yieldDMax : 40;
  }
  document.getElementById('dMinYield').value = dMin;
  document.getElementById('dMaxYield').value = dMax;
  var step = parseInt(document.getElementById('stepYield')?.value) || 2;

  var hRatio = parseFloat(document.getElementById('hRatioYield')?.value);
  if (!hRatio || isNaN(hRatio)) {
    var selSpecies = ForestCalc.SPECIES[document.getElementById('speciesSelect').value];
    hRatio = (selSpecies && selSpecies.defaultHRatio) ? selSpecies.defaultHRatio : 0.75;
  }
  document.getElementById('hRatioYield').value = hRatio;
  var result = ForestCalc.generateYieldTable(speciesId, dMin, dMax, step, hRatio);
  ForestCalc._yieldTableData = result;
  if (!result) { ForestCalc.showToast('生成失败，请检查树种数据', 'warn'); return; }

  var rows = result.rows;
  var html = '<div style="margin-top:16px;">';
  html += '<h4>📋 ' + result.species.name + ' 收方表 (D ' + dMin + '~' + dMax + 'cm, 步长 ' + step + 'cm, H/D=' + hRatio.toFixed(2) + ') <button class="btn btn-sm" style="margin-left:12px;" onclick="ForestCalc.exportYieldCSV()">📥 导出 CSV</button></h4>';
  html += '<div style="font-size:11px;color:var(--wood);margin-bottom:4px;">H/D 比来源: ' + (result.species.defaultHRatio && Math.abs(hRatio - result.species.defaultHRatio) < 0.001 ? '树种默认值 (' + hRatio.toFixed(2) + ')' : '用户自定义 (' + hRatio.toFixed(2) + ')') + ' | 可手动修改 H/D 比后重新生成</div>';
  html += '<div style="overflow-x:auto;"><table style="width:100%;border-collapse:collapse;font-size:13px;">';
  html += '<thead><tr style="background:rgba(196,165,110,0.12);">';
  html += '<th>D(cm)</th><th>H(m)</th><th>材积(m³)</th><th>规格材</th><th>非规格材</th><th>薪材</th><th>废材</th><th>经济材率</th>';
  html += '</tr></thead><tbody>';

  rows.forEach(function(r) {
    html += '<tr style="border-bottom:1px solid rgba(196,165,110,0.1);">';
    html += '<td>' + r.dbh + '</td>';
    html += '<td>' + r.height + '</td>';
    html += '<td style="font-weight:bold;">' + r.volume.toFixed(4) + '</td>';
    html += '<td>' + r.specVol.toFixed(4) + '</td>';
    html += '<td>' + r.nonSpecVol.toFixed(4) + '</td>';
    html += '<td>' + r.fuelVol.toFixed(4) + '</td>';
    html += '<td>' + r.wasteVol.toFixed(4) + '</td>';
    html += '<td>' + (r.econRate * 100).toFixed(1) + '%</td>';
    html += '</tr>';
  });

  html += '</tbody></table></div>';

  // 亩/公顷合计
  var density = parseInt(document.getElementById('density').value) || 0;
  var densityMu = parseInt(document.getElementById('densityMu').value) || 0;
  if (density > 0 || densityMu > 0) {
    html += '<div style="margin-top:8px;">';
    if (density > 0) {
      html += '<p style="font-size:12px;color:var(--wood);">📐 公顷合计: 总蓄积 ' + (rows.reduce(function(s,r){return s+r.volume;},0) * density).toFixed(2) + ' m³ (' + density + ' 株/公顷 × ' + rows.length + ' 级)</p>';
    }
    if (densityMu > 0) {
      html += '<p style="font-size:12px;color:var(--wood);">📐 亩合计: 总蓄积 ' + (rows.reduce(function(s,r){return s+r.volume;},0) * densityMu).toFixed(2) + ' m³ (' + densityMu + ' 株/亩 × ' + rows.length + ' 级)</p>';
    }
    html += '</div>';
  }
  html += '<p style="font-size:10px;color:#999;margin-top:4px;">\u203B 以上为理论最大值，实际林分中各径级分布不均</p>';

  html += '</div>';

  var container = document.getElementById('yieldTablePanel');
  container.innerHTML = html;
  container.style.display = '';
  document.getElementById('batchCard').style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth' });
};

// ========== v1.7.5 性能监控 ==========
ForestCalc._perfLog = [];
ForestCalc._logPerf = function(label, elapsed) {
  this._perfLog.push({ label: label, elapsed: elapsed, time: new Date().toLocaleTimeString() });
  if (this._perfLog.length > 50) this._perfLog.shift(); // 只保留最近 50 条
  console.log('[Perf] ' + label + ': ' + elapsed.toFixed(2) + ' ms');
};
